import React, { useEffect, useState } from 'react';
import { SafeAreaView, Text, TouchableOpacity, View , StyleSheet} from 'react-native';
import { useDispatch, useSelector } from "react-redux";

const PageTwo = ({ navigation }) => {

    const itemName = useSelector(state => state);

    const goToNextPage=()=>{
       navigation.push('PageThree');
    }

    return (
        <SafeAreaView style={styles.container}>
            <View style={styles.textContainer}>
                <Text style={styles.text}>{itemName.fieldValue}</Text>
            </View>

            <View style={styles.nextBtnContainer}>
            <TouchableOpacity onPress={goToNextPage} style={styles.btn}>
                    <Text>Next Screen for button design</Text>
            </TouchableOpacity>
            </View>
            
        </SafeAreaView>
    )
}

const styles = StyleSheet.create({
    container:{
        flex:1
    },
    textContainer:{
        flexDirection: 'row', 
        justifyContent: 'flex-end', 
        padding:5
    },
    text:{
        fontSize: 25
    },
    nextBtnContainer:{
        justifyContent: 'center', 
        alignItems: 'center', 
        marginTop: 100
    },
    btn:{
        backgroundColor:'#34bdeb', 
        width: 300, 
        height: 50, 
        borderRadius: 5, 
        padding: 10, 
        justifyContent: 'center', 
        alignItems:'center', 
        marginTop: 5
    }
})

export default PageTwo;