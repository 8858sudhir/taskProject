import React, { useEffect, useState } from 'react';
import { SafeAreaView, TextInput, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { useDispatch, useSelector } from "react-redux";
import { ADD_CONTENT } from '../actions/action';

const PageOne = ({ navigation }) => {
    const [inputVal, setInputVal] = useState('');
    const dispatch = useDispatch();

    const onChangeText = (val) => {
        setInputVal(val);
    }

    const goToNextPage = () => {
        dispatch({
            type: ADD_CONTENT,
            payload: inputVal
        });

        navigation.push('PageTwo');
    }

    return (
        <SafeAreaView style={styles.container}>

            <TextInput
                placeholder='Text'
                onChangeText={onChangeText}
                value={inputVal}
                style={styles.input}
            />

            <TouchableOpacity onPress={goToNextPage} style={styles.submit}>
                <Text >Submit</Text>
            </TouchableOpacity>
        </SafeAreaView>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center'
    },
    input: {
        borderColor: 'black',
        borderWidth: 1,
        width: 300,
        borderRadius: 5
    },
    submit: {
        backgroundColor: '#34bdeb',
        width: 300,
        height: 50,
        borderRadius: 5,
        padding: 10,
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: 5
    }
})

export default PageOne;
