import React, { useEffect, useState } from 'react';
import { SafeAreaView, Text, View, TouchableOpacity, StyleSheet } from 'react-native';
import { useDispatch, useSelector } from "react-redux";
import SwipeButton from 'rn-swipe-button';
import imgIcon from '../assets/icon.png';

const PageThree = ({ navigation }) => {
    const itemName = useSelector(state => state)
    return (
        <SafeAreaView style={styles.container}>

            <View style={styles.buttonContainer}>
                <Text style={styles.firstButton}>4 variations of button</Text>

                <TouchableOpacity style={styles.frstBtnCntnr}>
                    <Text style={styles.secondButton}>Press Me</Text>
                </TouchableOpacity>

                <TouchableOpacity style={styles.secondBtn}>
                    <Text style={styles.scndBtnText}>Press Me</Text>
                </TouchableOpacity>

                <TouchableOpacity style={styles.thirdBtn}>
                    <Text style={styles.thrdBtnText}>Press Me</Text>
                </TouchableOpacity>

                <SwipeButton
                    disabled={false}
                    swipeSuccessThreshold={70}
                    containerStyles={{ borderRadius: 5 }}
                    height={45}
                    width={330}
                    title="Swipe me to continoue"
                    titleColor='#07a6db'
                    thumbIconImageSource={imgIcon}
                    onSwipeSuccess={() => {
                        alert('Swiped Successfully!');
                    }}
                    railFillBackgroundColor="black"
                    railFillBorderColor="black"
                    thumbIconBackgroundColor="#07a6db"
                    thumbIconBorderColor="#07a6db"
                    railBackgroundColor="black"
                    railBorderColor="#07a6db"
                    thumbIconStyles={{ borderRadius: 5 }}
                />
            </View>
        </SafeAreaView>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: 'black'
    },
    buttonContainer: {
        marginTop: "70%",
        justifyContent: 'center',
        alignItems: 'center'
    },
    firstButton: {
        color: 'yellow'
    },
    secondButton: {
        color: '#34bdeb'
    },
    frstBtnCntnr: {
        margin: 20
    },
    secondBtn: {
        margin: 5,
        height: 45,
        width: 330,
        backgroundColor: '#45494a',
        borderRadius: 5,
        justifyContent: 'center',
        alignItems: 'center'
    },
    scndBtnText: {
        color: '#34bdeb'
    },
    thirdBtn: {
        margin: 5,
        height: 45,
        width: 330,
        backgroundColor: '#07a6db',
        borderRadius: 5,
        justifyContent: 'center',
        alignItems: 'center'
    },
    thrdBtnText: {
        color: 'white'
    }
})

export default PageThree;