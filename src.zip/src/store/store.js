import { createStore } from 'redux';
import addItemsReducer from '../reducers/reducer';

const store = createStore(addItemsReducer)

export default store;