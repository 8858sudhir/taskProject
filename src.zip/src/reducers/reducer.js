import { ADD_CONTENT } from "../actions/action";
const initialState = {
    fieldValue:''
};

const addItemsReducer = (state = initialState, action) => {
    const { type, payload } = action;
    switch (type) {
        case ADD_CONTENT:
          return {
              ...state, 
              fieldValue: payload
            }
      }
      return state;
}

export default addItemsReducer;